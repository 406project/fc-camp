﻿#target photoshop
var CC2015 = app.version.match(/^\d+/) >= 16;
var dlgWindow = new Window("dialog", "About");
dlgWindow.preferredSize = [300,-1];
dlgWindow.alignChildren = "left";

var aboutText = "PNG Express";
aboutText += "\nv.2.8.1";
aboutText += "\n\nVisit: www.pngexpress.com";
aboutText += "\n\nPlease report any issues or questions to: info@pngexpress.com";

dlgWindow.content = dlgWindow.add("statictext",undefined,aboutText,{multiline:true});
dlgWindow.content.alignment = "fill";
dlgWindow.content.alignChildren = ["left","center"];
if (!CC2015) {
    dlgWindow.content.preferredSize = [-1,100];
}
dlgWindow.grpButtons = dlgWindow.add("group");
dlgWindow.grpButtons.alignment = "right";
var dlgButtonOK = dlgWindow.grpButtons.add("button",undefined,"OK");
dlgButtonOK.minimumSize = [95,-1];

dlgButtonOK.onClick = function(){
    dlgWindow.close();
}

dlgWindow.show();
app.bringToFront();
    