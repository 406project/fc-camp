﻿if(typeof($)=='undefined')
	$={};

$._ext = {
    //Evaluate a file and catch the exception.
    evalFile : function(path) {
        try {
            $.evalFile(path);
        } catch (e) {alert("Exception:" + e);}
    },
    // Evaluate all the files in the given folder 
    evalFiles: function(jsxFolderPath) {
        var folder = new Folder(jsxFolderPath);
        if (folder.exists) {
            var jsxFiles = folder.getFiles("*.jsx");
            for (var i = 0; i < jsxFiles.length; i++) {
                var jsxFile = jsxFiles[i];
                $._ext.evalFile(jsxFile);
            }
        }
    }
};

/*
try{
    if ($.os.match(/windows/i)) {
        var idAdobeScriptAutomationScripts = stringIDToTypeID( "AdobeScriptAutomation Scripts" );
            var desc1 = new ActionDescriptor();
            var idjsNm = charIDToTypeID( "jsNm" );
            desc1.putString( idjsNm, """PNG Express Script UI Primer""" );
            var idjsMs = charIDToTypeID( "jsMs" );
            desc1.putString( idjsMs, """undefined""" );
        executeAction( idAdobeScriptAutomationScripts, desc1, DialogModes.NO );
    }
}catch(e){};
*/