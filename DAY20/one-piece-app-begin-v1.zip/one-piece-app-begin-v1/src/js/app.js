var angular = require('angular');
var app = angular.module('onePieceApp', []);

/**
 * --------------------------------
 * 컨트롤럴
 * ----------------------------- */
app.controller('OnepieceController', ['$scope', 'onepieceService', OnepieceController]);
function OnepieceController($scope, onepieceService) {
	$scope.onepiece_members = onepieceService.members;
}

/**
 * --------------------------------
 * 서비스
 * ----------------------------- */
app.service('onepieceService', ['$http', onepieceService]);
function onepieceService($http) {
	var self = this;
	self.members = [];
	$http
		.get('../data/one-piece.json')
		.then(function(response) {
			angular.forEach(response.data, function(member) {
				self.members.push(member);
			});
		});
}