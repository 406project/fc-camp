require('angular');
require('angular-route');

var app = angular.module('onePieceApp', ['ngRoute']);

app.config(function($routeProvider, $locationProvider) {

	$locationProvider
		// .hashPrefix('!')
		.html5Mode(true);

	$routeProvider
		.when('/list', {
			'templateUrl': 'views/list.html',
			'controller': 'ListController'
		})
		.when('/details/:id', {
			'templateUrl': 'views/details.html',
			'controller': 'DetailsController'
		})
		.otherwise({
			'redirectTo': '/list'
		});

});

/**
 * --------------------------------
 * 컨트롤러
 * ----------------------------- */
app.controller('ListController', ['$scope', 'onepieceService', ListController]);
function ListController($scope, onepieceService) {
	$scope.onepiece_members = onepieceService.members;
}

app.controller('DetailsController', ['$scope', 'onepieceService', '$routeParams', DetailsController]);
function DetailsController($scope, onepieceService, $routeParams) {

	$scope.members = onepieceService.members;
	$scope.member = $scope.members[ $scope.current_id ];

	$scope.current_id  = $routeParams.id - 0;
	$scope.previous_id = $scope.current_id <= 0 ? $scope.members.length - 1 : $scope.current_id - 1;
	$scope.next_id     = $scope.current_id >= $scope.members.length - 1 ? 0 : $scope.current_id + 1;
}

/**
 * --------------------------------
 * 서비스
 * ----------------------------- */
app.service('onepieceService', ['$http', onepieceService]);
function onepieceService($http) {
	var self = this;
	self.members = [];
	$http
		.get('../data/one-piece.json')
		.then(function(response) {
			angular.forEach(response.data, function(member) {
				self.members.push(member);
			});
		});
}