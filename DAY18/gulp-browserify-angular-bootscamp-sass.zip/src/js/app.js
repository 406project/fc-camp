/*! app.js © yamoo9.net, 2016 */
'use strict';

// 모듈
require('jquery');
require('angular');

// ------------------------------
// jQuery
// ------------------------------
jQuery.noConflict(true);


// ------------------------------
// AngularJS
// ------------------------------