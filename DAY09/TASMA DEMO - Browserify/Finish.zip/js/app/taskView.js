'use strict';

// jQuery 의존 모듈 호출
var $ = require('jquery');

/*
 * _renderTask
 * renderTasks
 * renderNew
 */
// var render_template = [
// 	'<li class="task clearfix">',
// 		'<div class="task-desc">',
// 			'<input type="checkbox" class="complete">',
// 			'<input type="text" class="description" maxlength="20" placeholder="등록할 내용을 기입해주세요.">',
// 		'</div>',
// 		'<button type="button" class="anim button remove">제거</button>',
// 	'</li>'
// ].join('');
var render_template = require('../../templates/task.hbs');

var _renderTask = function(task) {
	return $( render_template( task ) );
	// if ( task.complete ) {
	// 	$template.find('.complete').attr('checked', 'checked');
	// }
	// $template.find('.description').val( task.description );
	// return $template;
};

exports.renderTasks = function(tasks) {
	var $elsArray = $.map( tasks, _renderTask );
	$.$tasma.find('.tasks-list').empty().append( $elsArray );
};

exports.renderNew = function() {
	$.$tasma.find('.tasks-list').prepend( _renderTask( {} ) );
};