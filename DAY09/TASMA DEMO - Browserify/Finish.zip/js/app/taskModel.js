'use strict';

var DATA_NAME = 'TASMA';

exports.save = function(data) {
	data = JSON.stringify( data );
	localStorage.setItem( DATA_NAME, data );
};

exports.load = function() {
	var data = localStorage.getItem( DATA_NAME );
	if (data) {
		return JSON.parse( data );
	}
	return [];
};

exports.clear = function() {
	localStorage.removeItem( DATA_NAME );
};