'use strict';

// require() 함수 안에 `./`를 제외하면 node_modules/ 안에서 모듈을 찾음.
// TaskData     = require('data/taskModel')
// TaskRenderer = require('renderer/taskView')
var $            = require('jquery'),
	TaskData     = require('./taskModel'),
	TaskRenderer = require('./taskView');

exports.render = function() {
	TaskRenderer.renderTasks( TaskData.load() );
};

exports.add = function() {
	TaskRenderer.renderNew();
};

exports.clearAll = function() {
	TaskData.clear();
	exports.render();
};

exports.remove = function(ev) {
	var $target = $( ev.target );
	$target.closest('.task').remove();
};

exports.save = function() {
	var tasks = [], $tasks = $.$tasma.find('.task');
	$.each($tasks, function(index, task) {
		var $task = $tasks.eq(index);
		tasks.push({
			'complete'    : $task.find('.complete').prop('checked'),
			'description' : $task.find('.description').val()
		});
	});
	TaskData.save( tasks );
};

exports.cancel = function() {
	exports.render();
};