'use strict';

var $     = require('jquery'),
	Tasks = require('./app/taskController');

function _addTask() {
	Tasks.add();
}
function _clearAllTasks() {
	Tasks.clearAll();
}
function _saveChange() {
	Tasks.save();
}
function _cancelChanges() {
	Tasks.cancel();
}
function _deleteTask(ev) {
	Tasks.remove(ev);
}
function _registerEventHandler() {
	$.$tasma.find('.button.new').on('click', _addTask);
	$.$tasma.find('.button.new').on('click');
	$.$tasma.find('.button.remove-all').on('click', _clearAllTasks);
	$.$tasma.find('.button.save').on('click', _saveChange);
	$.$tasma.find('.button.cancel').on('click', _cancelChanges);
	$.$tasma.find('.tasks-list').on('click', '.remove', _deleteTask);
}
function init() {
	$.$tasma = $('#TASMA');
	_registerEventHandler();
	Tasks.render();
}
// DOM Ready
$(init);

