/*!
 * tasma.js © 2015
 * ------------------------------------
 *
 * 모듈(Module) 의존 구성
 * Model - View - Controller
 * ------------------------------------
 * Main < Tasks(C) < Data Storage(M)
 * 				   < Renderer(V)
 * ------------------------------------
 */

require.config({
	'baseUrl': 'js/',
	'paths': {
		'jquery': 'vender/jquery-2.1.4.min'
	},
	'urlArgs': 'ts=' + (new Date()).getTime()
});


require(['jquery'], function($) {
	'use strict';

	/**
	 * [Model]
	 * window.localStorage
	 * window.JSON
	 *
	 * load()
	 * save()
	 * clear()
	 * --------------------------------
	 */
	var DATA_NAME    = 'TASMA',
		global       = window,
		localStorage = global.localStorage,
		JSON         = global.JSON,
		parse        = JSON.parse,
		stringify    = JSON.stringify;

	function loadData() {
		var data = localStorage.getItem( DATA_NAME );
		if (data) {
			return parse( data );
		}
		return [];
	}

	function saveData( data ) {
		data = stringify( data );
		localStorage.setItem( DATA_NAME, data );
	}

	function clearData() {
		localStorage.removeItem( DATA_NAME );
	}

});