/*!
 * tasma.js © 2015
 * ------------------------------------
 *
 * 모듈(Module) 의존 구성
 * Model - View - Controller
 * ------------------------------------
 * Main < Tasks(C) < Data Storage(M)
 * 				   < Renderer(V)
 * ------------------------------------
 */

require.config({
	'baseUrl': 'js/',
	'paths': {
		'jquery': 'vender/jquery-2.1.4.min'
	},
	'urlArgs': 'ts=' + (new Date()).getTime()
});


require(['jquery'], function($) {
	'use strict';

	/**
	 * [Model] - DataManager
	 * window.localStorage
	 * window.JSON
	 *
	 * load()
	 * save()
	 * clear()
	 * --------------------------------
	 */
	var DATA_NAME    = 'TASMA',
		global       = window,
		localStorage = global.localStorage,
		JSON         = global.JSON,
		parse        = JSON.parse,
		stringify    = JSON.stringify;

	function loadData() {
		var data = localStorage.getItem( DATA_NAME );
		if (data) {
			return parse( data );
		}
		return [];
	}

	function saveData( data ) {
		data = stringify( data );
		localStorage.setItem( DATA_NAME, data );
	}

	function clearData() {
		localStorage.removeItem( DATA_NAME );
	}


	/**
	 * [View] - Renderer
	 * Dependency: [jQuery]
	 *
	 * renderTask()
	 * renderTasks()
	 * renderNew()
	 * --------------------------------
	 */

	var $tasma = $('#TASMA');

	// 템플릿
	var render_template = [
		'<li class="task clearfix">',
			'<div class="task-desc">',
				'<input class="complete" type="checkbox">',
				'<input class="description" maxlength="20" type="text" placeholder="등록할 내용을 기입해주세요.">',
			'</div>',
			'<button type="button" class="anim button remove">제거</button>',
		'</li>'
	].join('');

	function renderTask( task ) {
		// task?
		// { 'complete': true, 'description': '' }
		var $tml = $( render_template );
		if ( task.complete ) {
			$tml.find('.complete').attr('checked', 'checked');
		}
		$tml.find('.description').val( task.description );
		return $tml;
	}

	function renderTasks( tasks ) {
		// tasks?
		// [{...}, {...}]
		var $tasksArr = $.map(tasks, renderTask);
		$tasma.find('.tasks-list').empty().append( $tasksArr );
	}

	function renderNew() {
		$tasma.find('.tasks-list').prepend( renderTask( {} ) );
	}


	/**
	 * [Controller] - TasksManager
	 * Dependency: [jQuery, DataManager, Renderer]
	 *
	 * addTask()
	 * render()
	 * removeAllTasks()
	 * removeTask()
	 * saveTask()
	 * cancelTask()
	 * --------------------------------
	 */

	function addTask() {
		renderNew();
	}

	function render() {
		renderTasks( loadData() );
	}

	function removeAllTasks() {
		clearData();
		render();
	}

	function removeTask(ev) {
		var $event_target = $( ev.target );
		$event_target.closest('.task').remove();
	}

	function saveTask() {
		var tasks  = [],
			$tasks = $tasma.find('.task');

		$.each( $tasks, function(index, task) {
			var $task = $tasks.eq(index);
			tasks.push({
				'complete'    : $task.find('.complete').prop('checked'),
				'description' : $task.find('.description').val()
			});
		} );

		saveData( tasks );
	}

	function cancelTask() {
		render();
	}


	/**
	 * [App] - TASMA Application
	 * Dependency: [jQuery, TasksManager]
	 *
	 * registerEventHandlers()
	 * init()
	 * --------------------------------
	 */

	function registerEventHandlers() {
		$tasma.find('.button.new').on('click', addTask);
		$tasma.find('.button.remove-all').on('click', removeAllTasks);
		$tasma.find('.tasks-list').on('click', '.button.remove', removeTask);
		$tasma.find('.button.save').on('click', saveTask);
		$tasma.find('.button.cancel').on('click', cancelTask);
	}

	function init() {
		registerEventHandlers();
		render();
	}

	// $(document).ready(init);
	$(init);

});