///////////////////////////////////////////////////////////////////
    //메뉴에 대한 핸들링
    $("#gnb ul li a").on("click", function(){
        
        $("#gnb ul li a").removeClass("clicked");
        $(this).addClass("clicked");
        var clickIndex =  $("#gnb ul li a").index( $(this) ) ;
        
        $("#model >li").hide();
        
        if(clickIndex==6)
        {
            $("#model >li").eq(4).slideDown(200);
        }
        else if(clickIndex<4) {
            $("#model >li").eq(clickIndex).slideDown(200);
        }
        return false;
});

    
    //ㄴ 메뉴에 대한 핸들링 / 닫기버튼 누를 때 동작되는 핸들링
    $("#model >li >a").on("click", function(){
       $("#gnb ul li a").removeClass("clicked");
       $(this).parent().slideUp(200);
        return false;
});
    
///////////////////////////////////////////////////////////////////

    var height = [346,334,333,365];
    var $showingContainer = $(".showing .container").css('top', 0);
    //contents에 대한 슬라이드 핸들링 
    //li(#blog, #facebook, #twitter, #youtube)->컨테이너박스 .showing내부의 .container-> 액자
    var $contents_links_down = $("#contents li a.arrowDown").on("click", listSlideDown);
    var $contents_links_up = $("#contents li a.arrowUp").on("click", listSlideUp);
    
    
    function listSlideUp (e) {
        e.preventDefault();
        var $this, clickIndex, changeHeight;
        $this = $this ? $this : $(this);
        var thisParent = this.parentNode;
        
        clickIndex = $contents_links_up.index($this);
        changeHeight = height[clickIndex];
         var contentsLength = limitNumber(clickIndex);
        
        if ( !$.data(thisParent, 'clickCount') ) { $.data(thisParent, 'clickCount', 0); }    
        if($.data(thisParent, 'clickCount')<1) { $.data(thisParent, 'clickCount',contentsLength);}
        $.data(thisParent, 'clickCount', ( $.data(thisParent, 'clickCount') - 1 ));
        
        console.log(contentsLength);
        
        var currentTop = parseInt($showingContainer.eq(clickIndex).css('top'));
        if(currentTop>-height[clickIndex]){currentTop = -height[clickIndex]*(contentsLength);}
         
        console.log(contentsLength);

        $showingContainer.eq(clickIndex).css('top', currentTop + changeHeight + 'px');
        
        changeCountFn($.data(thisParent, 'clickCount') + 1, contentsLength, $this);
    }
    
    
    /**
     * listSlideDown 함수
     * 전달인자 : event object
     * 반환 값: undefined
     */
    function listSlideDown (e) {
        e.preventDefault();
        var $this, clickIndex, changeHeight;
        $this = $this ? $this : $(this);
        var thisParent = this.parentNode;

        clickIndex = $contents_links_down.index($this);
        changeHeight = height[clickIndex];        
        
        var contentsLength = limitNumber(clickIndex);
        
        if ( !$.data(thisParent, 'clickCount') ) { $.data(thisParent, 'clickCount', 0); }    
        $.data(thisParent, 'clickCount', ( ($.data(thisParent, 'clickCount') + 1) % contentsLength) );
        
        $showingContainer.eq(clickIndex).css('top', -(changeHeight * $.data(thisParent, 'clickCount') ) + 'px');
        
        changeCountFn($.data(thisParent,'clickCount')+1, contentsLength, $this);
    };
    /**
     * changeCountFn 함수
     * 전달인자 : count, $this
     * 반환 값: undefined
     */
    function changeCountFn( count, lastNumber,$this ) {
        $this.siblings('span').text( count+'/'+lastNumber );
    }
    /**
     * limitNumber 함수
     * 전달인자 : clickIndex
     * 반환 값 : number
     */
    function limitNumber(clickIndex) {
       if(clickIndex==2){ return 4; }
       if(clickIndex==3){ return 2; }
       return 5;
    };
    
    

    
    //news에 대한 핸들링 ul->컨테이너박스 #showingNews-> 액자
    $("#news>ul>li>a").on("click", function(){
        
        $("#news>ul>li>a").removeClass("selected");
        $(this).addClass("selected");
        
        
        var clickIndex =  $("#news>ul>li>a").index( $(this) ) ;
        $("#news #showingNews ul").css("top",-140*clickIndex);
        $("#news>img").css("top",+20*clickIndex+50);
        return false;
    })