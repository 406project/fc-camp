// 클로저 활용 : Closure
;(function ($, undefined) {

    // 엄격한 문법 모드 발동 : STRICT MODE
    "use strict";

    // 헬퍼 참조 변수 설정 : defind helper local variables
    var win = window,
        doc = document,
        html = doc.documentElement,
        init;

    // 초기화 실행 함수
    init = function () {
        
        /************************************************************************
         * 검색 버튼 토글 코드
         */
        
        // .set-loc
        var $set_loc = $('.set-loc'),
            $dong_srch = $('.dong-srch');

        $set_loc.on('click', function () {
            $dong_srch.toggleClass('show');
            $dong_srch.find('input').focus();
        });
        
        /************************************************************************
         * 커버 이미지 변경 코드
         */
        var $container = $('.container');
        var $content = $container.find('.content');

        $container.find(".col1").on({
            "mouseenter" : function(e) {
                var $this = $(this);
                if ($this.hasClass('dontmove')) { return; }
                // 마우스가 올라간 .col1을 제외한 나머지 .col1은 클래스 dontmove 설정
                $content.find('.col1').addClass('dontmove');
                $this.removeClass('dontmove');

                var parentOffset = $this.offset();
                var relX = e.pageX - parentOffset.left - 200;
                var relY = e.pageY - parentOffset.top - 200;

                $this.find(".cover")
                .css('background-position', relX + "px " + relY + "px")
                .animate({
                    backgroundPositionX: 0,
                    backgroundPositionY: 0
                }, 200);
            },
            "mouseleave" : function(e) {
                var $this = $(this);
                var parentOffset = $this.offset();
                var relX = e.pageX - parentOffset.left + 200;
                var relY = e.pageY - parentOffset.top + 200;

                $this.find(".cover").animate({
                    backgroundPositionX: relX,
                    backgroundPositionY: relY
                }, 200, function() {
                    $content.find('.dontmove').removeClass('dontmove');
                });
            }
        });
        
        /************************************************************************
         * 슬라이드 콘텐츠 이미지 코드
         */
        var $promo = $('.promo'),
            $promotion = $promo.find('.promotion'),
            $btns = $promo.find('.btn-control');
        
        $.each($promotion.find('li'), function(i, el) {
            $(el).attr('data-id', i);
        });
        
        $btns.on('click', 'a', function(e) {
            e.preventDefault();
            if ( e.target.className == 'prev') {
                var $last = $promotion.children().last().detach();
                $promotion.prepend($last);
            } else {
                 var $first = $promotion.children().first().detach();
                $promotion.append($first);
            }
            var id = $promotion.children().first().data('id');
            $promo.find('.btn a').css('background-position', '-50px 0');
            $promo.find('.btn a').eq(id).css('background-position', '0 0');
        });
        
        
        
        /************************************************************************
         * 슬라이드 .bt-content 이미지 코드
         */
        var $bt_content = $container.find('.bt-content');
        var $cont_ul = $bt_content.find('.cont-area ul');
        var $cont_li = $cont_ul.children();
        var cont_li_count = $cont_li.length/2;
        var content_w = $cont_li.first().width();
        
        $cont_ul.width( cont_li_count * content_w + 20 );
        
        $bt_content.find('.btn-group a').on('click', function(e) {
            e.preventDefault();
            var $this = $(this);            
            for(var i=1; i<3; i++) {
                if ($this.hasClass('prev'+i)) {
                    var _ul = $cont_ul.eq(i-1);
                    var $last = _ul.children(':last').detach();
                    _ul
                        .prepend($last)
                        .css('left', -content_w)
                        .stop()
                        .animate({'left' : 0}, 300);
                }
                else if ($this.hasClass('next'+i)) {
                    var _ul = $cont_ul.eq(i-1);
                    var $first = _ul.children(':first');
                    _ul
                        .stop()
                        .animate({'left' : -content_w}, 300, function() {
                                $first.detach();
                                _ul
                                    .css('left', 0)
                                    .append($first);
                        });
                }
            }
        });

    };

    // 문서가 준비되면 실행 : DOM Ready
    $(document).ready(init);

})(window.jQuery);