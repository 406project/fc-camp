# Modernizr-min
Minified version of [Modernizr](http://modernizr.com).

## Install
You can install this package with `bower`.

```
bower install modernizr-min --save
```
